package event;

import java.time.LocalDateTime;
import java.util.UUID;

public class Event {
    private String id;
    private String title;
    private String desc;
    private LocalDateTime time;
    private EventType type;
    private String portfolioId;

    public Event() {
        this.id = UUID.randomUUID().toString();
    }

    public enum EventType {
        HACK, CRASH, LEGAL_DECISION, MARKET_NEWS, CUSTOM
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public EventType getType() {
        return type;
    }

    public void setType(EventType type) {
        this.type = type;
    }

    public String getPortfolioId() {
        return portfolioId;
    }

    public void setPortfolioId(String portfolioId) {
        this.portfolioId = portfolioId;
    }
}