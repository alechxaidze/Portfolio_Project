package event;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class WhaleMonitor {
    private EventManager eventManager;
    private Map<String, Double> thresholds;

    public WhaleMonitor(EventManager em) {
        this.eventManager = em;
        thresholds = new HashMap<>();
        thresholds.put("BTC", 100000.0);
        thresholds.put("ETH", 10000.0);
        thresholds.put("BNB", 5000.0);
    }

    public void setThreshold(String token, double val) {
        thresholds.put(token, val);
    }

    public void monitorAddress(String blockchain, String addr) {
        ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
        executor.scheduleAtFixedRate(() -> {
            List<Transaction> transactions = fetchTransactions(blockchain, addr);
            for (Transaction tx : transactions) {
                processTransaction(tx);
            }
        }, 0, 5, TimeUnit.MINUTES);
    }

    private List<Transaction> fetchTransactions(String blockchain, String address) {
        return new ArrayList<>();
    }

    private void processTransaction(Transaction tx) {
        String token = tx.getTokenSymbol();
        double txAmount = tx.getAmount();
        double threshold = thresholds.getOrDefault(token, 50000.0);

        if (txAmount >= threshold) {
            WhaleAlert alert = new WhaleAlert();
            alert.setBlockchain(tx.getBlockchain());
            alert.setToken(token);
            alert.setAmount(txAmount);
            alert.setFromAddr(tx.getFromAddr());
            alert.setToAddr(tx.getToAddr());
            alert.setTime(tx.getTime());
            alert.setRelated(true);

            Event event = new Event();
            event.setTitle("Whale Alert: " + token);
            event.setDesc("Large transaction detected: " + txAmount + " " + token);
            event.setTime(tx.getTime());
            event.setType(Event.EventType.MARKET_NEWS);
            eventManager.addEvent(event);
        }
    }
}