package event;

import java.time.LocalDateTime;
import java.util.TreeSet;
import java.util.List;
import java.util.ArrayList;

public class EventManager {
    private TreeSet<Event> allEvents = new TreeSet<>((a,b)->a.getTime().compareTo(b.getTime()));

    public void addEvent(Event event) {
        allEvents.add(event);
    }

    public void deleteEvent(String eventId) {
        allEvents.removeIf(e -> e.getId().equals(eventId));
    }

    public List<Event> queryEvents(LocalDateTime start, LocalDateTime end, String portfolioId, Event.EventType type) {
        List<Event> res = new ArrayList<>();
        for(Event e : allEvents) {
            boolean match = true;
            if(start != null && e.getTime().isBefore(start)) match = false;
            if(end != null && e.getTime().isAfter(end)) match = false;
            if(portfolioId != null && !portfolioId.equals(e.getPortfolioId())) match = false;
            if(type != null && e.getType() != type) match = false;
            if(match) res.add(e);
        }
        return res;
    }
}