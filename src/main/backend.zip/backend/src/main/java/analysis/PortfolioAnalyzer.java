package analysis;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class PortfolioAnalyzer {
    private static PortfolioAnalyzer instance;

    private PortfolioAnalyzer() {}

    public static PortfolioAnalyzer getInstance() {
        if (instance == null) {
            instance = new PortfolioAnalyzer();
        }
        return instance;
    }

    public double calculateProfitFrequency(Portfolio portfolio, LocalDate startDate, LocalDate endDate) {
        List<HistoricalPrice> history = portfolio.getHistoricalValueHistory();
        long totalDays = ChronoUnit.DAYS.between(startDate, endDate) + 1;
        long profitableDays = 0;
        double totalCost = portfolio.getTotalPurchaseCost();

        for (HistoricalPrice hp : history) {
            LocalDate priceDate = hp.getDate();
            if (priceDate.isAfter(startDate.minusDays(1)) && priceDate.isBefore(endDate.plusDays(1))) {
                if (hp.getPrice() > totalCost) {
                    profitableDays++;
                }
            }
        }
        return totalDays == 0 ? 0 : new BigDecimal((double) profitableDays / totalDays * 100).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    public double calculateROI(Portfolio portfolio) {
        double totalValue = portfolio.getTotalValue();
        double totalCost = portfolio.getTotalPurchaseCost();
        if (totalCost == 0) return 0;
        double roi = (totalValue - totalCost) / totalCost * 100;
        return new BigDecimal(roi).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    public double calculateMaxDrawdown(Portfolio portfolio, LocalDate startDate, LocalDate endDate) {
        List<HistoricalPrice> history = portfolio.getHistoricalValueHistory();
        double maxPeak = Double.MIN_VALUE;
        double maxDrawdown = 0.0;

        for (HistoricalPrice hp : history) {
            LocalDate priceDate = hp.getDate();
            if (priceDate.isAfter(startDate.minusDays(1)) && priceDate.isBefore(endDate.plusDays(1))) {
                double currentValue = hp.getPrice();
                maxPeak = Math.max(maxPeak, currentValue);
                double drawdown = (maxPeak - currentValue) / maxPeak * 100;
                maxDrawdown = Math.max(maxDrawdown, drawdown);
            }
        }
        return new BigDecimal(maxDrawdown).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    public Map<String, Double> calculateAssetAllocation(Portfolio portfolio) {
        Map<String, Double> allocation = new HashMap<>();
        double totalValue = portfolio.getTotalValue();
        if (totalValue == 0) return allocation;

        for (Asset asset : portfolio.getAssets()) {
            String symbol = asset.getSymbol();
            double assetValue = asset.getQuantity() * asset.getCurrentPrice();
            double ratio = (assetValue / totalValue) * 100;
            allocation.put(symbol, new BigDecimal(ratio).setScale(2, RoundingMode.HALF_UP).doubleValue());
        }
        return allocation;
    }

    public List<ComparisonResult> comparePortfolios(List<Portfolio> portfolios, String indicator) {
        List<ComparisonResult> results = new ArrayList<>();
        for (Portfolio portfolio : portfolios) {
            ComparisonResult res = new ComparisonResult();
            res.setPortfolioName(portfolio.getName());
            res.setIndicatorName(indicator);
            switch (indicator) {
                case "ROI":
                    res.setIndicatorValue(calculateROI(portfolio));
                    break;
                case "ProfitFrequency":
                    res.setIndicatorValue(calculateProfitFrequency(portfolio, LocalDate.now().minusMonths(3), LocalDate.now()));
                    break;
                case "MaxDrawdown":
                    res.setIndicatorValue(calculateMaxDrawdown(portfolio, LocalDate.now().minusMonths(3), LocalDate.now()));
                    break;
            }
            results.add(res);
        }
        results.sort((a, b) -> Double.compare(b.getIndicatorValue(), a.getIndicatorValue()));
        return results;
    }
}