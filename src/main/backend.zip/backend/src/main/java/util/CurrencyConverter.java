package util;

import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class CurrencyConverter {
    private static CurrencyConverter instance;
    private Map<String, Double> rateCache;

    private CurrencyConverter() {
        initRate();
    }

    public static CurrencyConverter getInstance() {
        if (instance == null) {
            instance = new CurrencyConverter();
        }
        return instance;
    }

    private void initRate() {
        rateCache = new HashMap<>();
        rateCache.put("USD", 1.0);
        rateCache.put("EUR", 0.92);
        rateCache.put("CNY", 7.10);
        rateCache.put("GBP", 0.79);
    }

    public double convert(double amount, String fromCurrency, String toCurrency) {
        if (fromCurrency.equals(toCurrency)) return amount;
        double fromRate = rateCache.get(fromCurrency);
        double toRate = rateCache.get(toCurrency);
        return BigDecimal.valueOf(amount)
                .multiply(BigDecimal.valueOf(toRate))
                .divide(BigDecimal.valueOf(fromRate),2, RoundingMode.HALF_UP)
                .doubleValue();
    }
}