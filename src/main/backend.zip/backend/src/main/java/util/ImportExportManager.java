package util;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.util.List;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import java.nio.charset.StandardCharsets;

public class ImportExportManager {
    private CurrencyConverter converter = CurrencyConverter.getInstance();

    public Portfolio importFromCsv(File csvFile, String portfolioName, String refCurrency) throws IOException {
        Portfolio portfolio = new Portfolio();
        portfolio.setName(portfolioName);
        portfolio.setReferenceCurrency(refCurrency);

        util.CSVParser parser = CSVParser.parse(csvFile, StandardCharsets.UTF_8, CSVFormat.DEFAULT.withHeader());
        for (CSVRecord record : parser) {
            String type = record.get("Transaction Type");
            if ("BUY".equals(type)) {
                String symbol = record.get("Asset");
                double quantity = Double.parseDouble(record.get("Quantity"));
                double price = Double.parseDouble(record.get("Price"));
                String priceCurrency = record.get("Currency");

                double convertedPrice = converter.convert(price, priceCurrency, refCurrency);
                Asset asset = new Asset();
                asset.setSymbol(symbol);
                asset.setQuantity(quantity);
                asset.setPurchasePrice(convertedPrice);
                portfolio.addAsset(asset);
            }
        }
        return portfolio;
    }

    public void exportToCsv(Portfolio portfolio, File outputFile) throws IOException {
        FileWriter writer = new FileWriter(outputFile);
        writer.append("Asset Symbol,Quantity,Purchase Price,Current Price,Value\n");

        for (Asset asset : portfolio.getAssets()) {
            writer.append(asset.getSymbol())
                    .append(",").append(String.valueOf(asset.getQuantity()))
                    .append(",").append(String.valueOf(asset.getPurchasePrice()))
                    .append(",").append(String.valueOf(asset.getCurrentPrice()))
                    .append(",").append(String.valueOf(asset.getQuantity()*asset.getCurrentPrice()))
                    .append("\n");
        }
        writer.flush();
        writer.close();
    }
}